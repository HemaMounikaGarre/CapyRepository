package com.cg.oad.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.oad.dto.AdDetails;
import com.cg.oad.dto.Registration;

@Repository
public class AdDaoImpl implements AdDaoI{

	@Autowired
	MongoTemplate mongoTemplate;
	
	
	
	
	
	@Override
	public void register(Registration registration) {
		mongoTemplate.save(registration);
		
	}
	
	
	@Override
	public Boolean validate(String mail, String password) {
		List<Registration> userDetails=mongoTemplate.findAll(Registration.class);
		for (Registration registration : userDetails) {
			if(registration.getEmailId().equals(mail)&& registration.getPassword().equals(password))
				return true;
		
		}
		return false;
	}
	
	
	
	
	
	@Override
	public void postAd(AdDetails adDetails) {
		
		
		mongoTemplate.save(adDetails);
		
	}

	@Override
	public List<AdDetails> getd(String name) {
		List<AdDetails> details= mongoTemplate.findAll(AdDetails.class);
		List<AdDetails> result=new ArrayList<>();
		for (AdDetails adDetails : details) {
			if(adDetails.getCategory().equals(name))
			{
				
				result.add(adDetails);
			}
			
		}
			
		return result;
	}
	


	
	
	@Override
	public void deleteAdd(String id) {
		List<AdDetails> details=mongoTemplate.findAll(AdDetails.class);
		for (AdDetails adDetails2 : details) {
			if(adDetails2.getGenUniqId().equals(id))
		
		
		mongoTemplate.remove(adDetails2);
		}
		
	}


	@Override
	public void update(AdDetails adDetails) {
		// TODO Auto-generated method stub
		AdDetails object=mongoTemplate.findById(adDetails.getGenUniqId(),AdDetails.class);
		deleteAdd(adDetails.getGenUniqId());
		object.setCategory(adDetails.getCategory());
		object.setContactNo(adDetails.getContactNo());
		object.setDescription(adDetails.getDescription());
		object.setEmailId(adDetails.getEmailId());
		object.setGenUniqId(adDetails.getGenUniqId());
		object.setName(adDetails.getName());
		object.setPrice(adDetails.getPrice());
		mongoTemplate.insert(object);
		
		
	}
	
	

	

	

}

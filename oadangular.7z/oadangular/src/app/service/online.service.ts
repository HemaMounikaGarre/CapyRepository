import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http'
import { from } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class OnlineService {

  constructor(private http:HttpClient) { }
  adduser(data:any){
    let input={"name":data.name,"emailId":data.mailId,"contactNo":data.phoneNumber,
    "password":data.password};
   
     return this.http.post("http://localhost:9999/register",input);
    
  }
  searchAd(category)
  {
    return this.http.get("http://localhost:9999/getad/"+category);
  }
}

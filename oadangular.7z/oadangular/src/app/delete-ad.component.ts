import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-ad',
  templateUrl: './delete-ad.component.html',
  styleUrls: ['./delete-ad.component.css']
})
export class DeleteAdComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  OnDelete()
  {
    alert("deleted successfully");
  }
}

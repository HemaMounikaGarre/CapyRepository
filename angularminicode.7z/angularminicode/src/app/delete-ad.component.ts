import { Component, OnInit } from '@angular/core';
import { OnlineService } from './service/online.service';

@Component({
  selector: 'app-delete-ad',
  templateUrl: './delete-ad.component.html',
  styleUrls: ['./delete-ad.component.css']
})
export class DeleteAdComponent implements OnInit {

  constructor(private service:OnlineService) { }

  ngOnInit() {
  }

  

  onSubmit(values){
    console.log(values);
    this.service.DeleteAd(values).subscribe();
 
  }
}

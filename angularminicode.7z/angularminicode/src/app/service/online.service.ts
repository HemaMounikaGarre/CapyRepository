import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http'
import { from } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class OnlineService {

  constructor(private http:HttpClient) { }
  adduser(data:any){
    let input={"name":data.name,"emailId":data.mailId,"contactNo":data.phoneNumber,
    "password":data.password};
   
     return this.http.post("http://localhost:9999/register",input);
    
  }
  searchAd(category)
  {
    return this.http.get("http://localhost:9999/getad/"+category);
  }
  addpostAd(data:any){
    let input={"name":data.proname,"emailId":data.email,"genUniqId":data.uniqueid,
     "description":data.description,"category":data.cname,"price":data.pprice,"contactNo":data.cno}
 
 //console.log("---in service:"+input);
   return this.http.post("http://localhost:9999/postad",input);
     }
 DeleteAd(data)
 {
  console.log("---in service:"+data);
   return this.http.delete("http://localhost:9999/removead/"+data.uniqueid)
 }
}

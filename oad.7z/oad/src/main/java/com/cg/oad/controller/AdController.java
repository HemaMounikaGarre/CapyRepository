package com.cg.oad.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.oad.dto.AdDetails;
import com.cg.oad.dto.Registration;
import com.cg.oad.service.AdSeviceImpl;

@RestController
public class AdController {
	
	@Autowired
	AdSeviceImpl adServiceImpl;

	
	
	@PostMapping("/register")
	public void register(@RequestBody Registration registration) {
		adServiceImpl.register(registration);
	}
	
	@GetMapping("/verifyuser/{emailId}/{password}")
	public Boolean validate(@PathVariable("emailId") String emailId, @PathVariable("password") String password) {
		return adServiceImpl.validate(emailId, password);
		
	}
	
	
	
	@PostMapping("/postad")
	public void postAd(@RequestBody AdDetails adDetails) {
		adServiceImpl.postAd(adDetails);
	}
	
	@GetMapping("/getad")
	public List<AdDetails> getdetails() {
		return adServiceImpl.getd();
	}
	
	@DeleteMapping("/removead/{id}")
	public void deleteAdd(@PathVariable("id") String id) {
		adServiceImpl.deleteAdd(id);
	}
	@PutMapping("/update")
	public void update(@RequestBody AdDetails adDetails) {
	adServiceImpl.update(adDetails);
	}
	
}

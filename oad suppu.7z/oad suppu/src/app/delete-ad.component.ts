import { Component, OnInit } from '@angular/core';
import { OnlineService } from './service/online.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-delete-ad',
  templateUrl: './delete-ad.component.html',
  styleUrls: ['./delete-ad.component.css']
})
export class DeleteAdComponent implements OnInit {

  constructor(private service:OnlineService) { }

  ngOnInit() {
  }

  
  onDelete()
  {
    Swal.fire(
      'Good job!',
      'You have deleted one item!',
      'success'
    )
  }
  onSubmit(values){
    console.log(values);
    this.service.DeleteAd(values).subscribe();
 
  }
}
